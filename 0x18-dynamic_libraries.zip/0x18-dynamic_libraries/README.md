README File for 0x18. C - Dynamic libraries project
