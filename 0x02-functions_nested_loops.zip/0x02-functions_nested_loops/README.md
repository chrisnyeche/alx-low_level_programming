Functions and Nested Loops
